FARALAG AC GUI V1

This is the first Windows GUI stage.
It has:
- Check ID field
- Start Scan button
- progress bar
- connection test to faralag.ro
- online report button

The actual anti-cheat scanning engine is intentionally NOT included in V1 yet.
